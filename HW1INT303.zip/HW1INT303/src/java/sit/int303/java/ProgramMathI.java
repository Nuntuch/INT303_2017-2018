/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sit.int303.java;

import java.util.ArrayList;

/**
 *
 * @author Nuntuch Thongyoo
 */
public interface ProgramMathI {

    boolean getLoopCheckPrimeNumber();

    ArrayList<Integer> FindFactor(int num);

    boolean OodOrEven(int num);

}
